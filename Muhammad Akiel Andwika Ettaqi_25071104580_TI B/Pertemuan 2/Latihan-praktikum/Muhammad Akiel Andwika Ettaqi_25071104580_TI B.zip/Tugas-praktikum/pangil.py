import myMath as my

print(my.penambahan(2,5))
print(my.fibonacci(5))